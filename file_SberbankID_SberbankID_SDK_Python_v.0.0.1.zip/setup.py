import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="pySberId",
    version="0.0.1",
    author='ПАО "Сбербанк России"',
    author_email="support_ecomm@sberbank.ru",
    description="Библиотека для серверных приложений, упрощающая получение Access Token и UserInfo.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://psi.developer.sberbank.ru/psi/psi1/doc/v1/sberbank-id/PythonSDK",
    packages=setuptools.find_packages(exclude=("examples", "tests", "test*")),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        'requests_pkcs12', 'pyjwt'
    ],
)
