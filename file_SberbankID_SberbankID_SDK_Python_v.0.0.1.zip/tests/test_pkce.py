import unittest
from sberid.pkce import  PKCEData, PKCEMethod


class Test(unittest.TestCase):
    CODE_CHALLENGE= "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk";
    CODE_VERIFIER = "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM";

    def test_code_verifier(self):
        for pkce_method in (PKCEMethod.S256, PKCEMethod.PLAIN):
            with self.subTest("Генерирование значения code_verifier", pkce_method=pkce_method):
                pkceData = PKCEData(pkce_method, 64)
                verifier1 = pkceData.code_verifier
                pkceData = PKCEData(pkce_method, 64)
                verifier2 = pkceData.code_verifier
                self.assertNotEqual(verifier1, verifier2, "Ошибка генерирования значения code_verifier")
                self.assertEqual(len(verifier1), 64, "Ошибка генерирования значения code_verifier")
                self.assertEqual(len(verifier2), 64, "Ошибка генерирования значения code_verifier")

    def test_code_challendge_S256(self):
        pkce_method = PKCEMethod.S256
        self.assertEqual(pkce_method.encode(self.CODE_CHALLENGE), self.CODE_VERIFIER, "Ошибка хеширования значения code_verifier")

    def test_code_challendge_PLAIN(self):
        pkce_method = PKCEMethod.PLAIN
        self.assertEqual(pkce_method.encode(self.CODE_CHALLENGE), self.CODE_CHALLENGE, "Ошибка хеширования значения code_verifier")

