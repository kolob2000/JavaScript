import unittest
from unittest import mock
from sberid.client import Consumer
from sberid.apirequest import TokenRequest, APIErrorResponse, UserIdRequest


def mocked_uuid(*args, **kwargs):
    return "mocked_uuid"


def mocked_requests(*args, **kwargs):
    class MockResponse:
        def __init__(self, json_data, status_code):
            self.json_data = json_data
            self.status_code = status_code
            self.content = "mocked content"

        def json(self):
            return self.json_data
    URL_DB = {
        "userinfo.do": {
            "json_data": {
                "headers": kwargs.get("headers"),
                "data": kwargs.get("data"),
                "params": kwargs.get("params")
            },
            "status_code": 200
        },
        "token.do": {
            "json_data": {
                "headers": kwargs.get("headers"),
                "data": kwargs.get("data"),
                "params": kwargs.get("params")
            },
            "status_code": 200
        },
        "error.do": {
            "json_data": {
                "httpCode": "400",
                "httpMessage": "error_message",
                "moreInformation": "more_information"
            },
            "status_code": 400
        }
    }
    return MockResponse(**URL_DB[kwargs["url"]])


class Test(unittest.TestCase):

    def setUp(self):
        self.consumer = Consumer(
            client_id = "client_id",
            client_secret = "client_secret",
            client_crt = None,
            client_pass = None
        )

    @mock.patch("sberid.apirequest.requests_pkcs12.post", side_effect=mocked_requests)
    @mock.patch("sberid.apirequest.uuid.uuid4", side_effect=mocked_uuid)
    def test_token_do(self, mock_get, mock_uuid):
        with self.subTest("Проверка параметров успешного запроса"):
            with self.assertLogs("sberid.apirequest", level="DEBUG") as cm:
                request = TokenRequest("token.do", self.consumer)
                response = request.send("auth_code", "redirect_url")
            self.assertEqual(len(cm.output), 2)
            self.assertEqual(response, {'data': 'grant_type=authorization_code&code=auth_code&client_id=client_id&client_secret=client_secret&redirect_uri=redirect_url',
                                        'headers': {'Content-Type': 'application/x-www-form-urlencoded',
                                                    'accept': 'application/json',
                                                    'rquid': 'mocked_uuid',
                                                    'x-ibm-client-id': 'client_id'},
                                        'params': None}, "Ошибка компоновки параметров запроса")

        with self.subTest("Проверка не успешного запроса"):
            msg = "Ошибка формирования атрибута исключения: {0}"
            with self.assertRaises(APIErrorResponse) as ex:
                request = TokenRequest("error.do", self.consumer)
                request.send("auth_code", "redirect_url")

            self.assertEqual(str(ex.exception), "more_information", msg.format("moreInformation"))
            self.assertEqual(ex.exception.httpCode, "400", msg.format("httpCode"))
            self.assertEqual(ex.exception.httpMessage, "error_message", msg.format("httpMessage"))
            self.assertEqual(ex.exception.moreInformation, "more_information", msg.format("moreInformation"))
        self.assertEqual(len(mock_get.call_args_list), 2)

    @mock.patch("sberid.apirequest.requests_pkcs12.get", side_effect=mocked_requests)
    @mock.patch("sberid.apirequest.uuid.uuid4", side_effect=mocked_uuid)
    def test_userinfo_do(self, mock_get, mock_uuid):
        with self.subTest("Проверка параметров успешного запроса"):
            with self.assertLogs("sberid.apirequest", level="DEBUG") as cm:
                request = UserIdRequest("userinfo.do", self.consumer)
                response = request.send("access_token")
            self.assertEqual(len(cm.output), 2)
            self.assertEqual(response, {'headers': {'x-introspect-rquid': 'mocked_uuid',
                                                    'x-ibm-client-id': 'client_id',
                                                    'authorization': 'Bearer access_token',
                                                    'accept': 'application/json'
                                                    },
                                        'data': None,
                                        'params': ''}, "Ошибка компоновки параметров запроса")

        with self.subTest("Проверка не успешного запроса"):
            msg = "Ошибка формирования атрибута исключения: {0}"
            with self.assertRaises(APIErrorResponse) as ex:
                request = UserIdRequest("error.do", self.consumer)
                response = request.send("access_token")

            self.assertEqual(str(ex.exception), "more_information", msg.format("moreInformation"))
            self.assertEqual(ex.exception.httpCode, "400", msg.format("httpCode"))
            self.assertEqual(ex.exception.httpMessage, "error_message", msg.format("httpMessage"))
            self.assertEqual(ex.exception.moreInformation, "more_information", msg.format("moreInformation"))
        self.assertEqual(len(mock_get.call_args_list), 2)
