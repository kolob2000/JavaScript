import json
import time
import uuid
import base64
import datetime


def base64url_encode(data):
    return base64.urlsafe_b64encode(data.encode('utf-8')).decode().replace('=', '')


def encode_id_token(f):
    def wrap(*args, **kwargs):
        payload = f(*args, **kwargs)
        header = {"alg": "none"}
        segments = []
        segments.append(base64url_encode(json.dumps(header, separators=(',', ':'))))
        segments.append(base64url_encode(json.dumps(payload, separators=(',', ':'))))
        segments.append("")
        return '.'.join(segments)
    return wrap


class IdTokenMock():

    def setUp(self):
        self.auth_time = time.mktime(datetime.datetime.now().timetuple())
        self.iat = time.mktime(datetime.datetime.now().timetuple())
        self.exp = time.mktime((datetime.datetime.now() + datetime.timedelta(seconds = 60)).timetuple())
        self.nonce = "Yx2fTcx5waqqsCzT"
        self.sub = "0" * 80
        self.sid = "0c9fd66a9be337290abe6b59f49dd0ab"
        self.aud = "mocked_aud"
        self.iss = "https://online.sberbank.ru/CSAFront/index.do"

    @property
    @encode_id_token
    def id_token(self):
        payload = {
            "sub": self.sub,
            "auth_time": self.auth_time,
            "nonce": self.nonce,
            "sid": self.sid,
            "iss": self.iss,
            "iat": self.iat,
            "exp": self.exp,
            "aud": self.aud
        }
        return payload

    @property
    @encode_id_token
    def expired_id_token(self):
        payload = {
            "sub": self.sub,
            "auth_time": self.auth_time,
            "nonce": self.nonce,
            "sid": self.sid,
            "iss": self.iss,
            "iat": self.iat,
            "exp": time.mktime((datetime.datetime.now() + datetime.timedelta(seconds = -1)).timetuple()),
            "aud": self.aud
        }
        return payload
