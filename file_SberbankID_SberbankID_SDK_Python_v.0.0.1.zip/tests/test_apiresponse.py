import uuid
import unittest
from tests.utils import IdTokenMock
from sberid.apiresponse import AuthorizationResponse, AccessTokenResponse, AuthException, SberAPIException


class Test(IdTokenMock, unittest.TestCase):

    def test_auth_redirect_error_response(self):
        msg = "Ошибка формирования параметра '{0}' исключения"
        with self.assertRaises(AuthException) as ex:
            AuthorizationResponse(
                error="server_error",
                state="fake_state",
                nonce="fake_nonce"
            )
        self.assertEqual(ex.exception.state, "fake_state", msg.format("state"))
        self.assertEqual(ex.exception.nonce, "fake_nonce", msg.format("nonce"))
        self.assertEqual(str(ex.exception), "server_error", msg.format("message"))

    def test_api_error_response(self):
        msg = "Ошибка валидации аттрибута id_token: '{0}'"

        with self.subTest("Тест некорректного параметра issuer"):
            with self.assertRaises(SberAPIException) as ex:
                AccessTokenResponse(self.iss + "_", self.aud, str(uuid.uuid4()), self.exp, "bearer", "openid", self.id_token)
            self.assertEqual(str(ex.exception), "Invalid issuer", msg.format("iss"))

        with self.subTest("Тест некорректного параметра audience"):
            with self.assertRaises(SberAPIException) as ex:
                AccessTokenResponse(self.iss, self.aud + "_", str(uuid.uuid4()), self.exp, "bearer", "openid", self.id_token)
            self.assertEqual(str(ex.exception), "Invalid audience", msg.format("aud"))

        with self.subTest("Токен с истекшим сроком действия"):
            with self.assertRaises(SberAPIException) as ex:
                AccessTokenResponse(self.iss, self.aud + "_", str(uuid.uuid4()), self.exp, "bearer", "openid", self.expired_id_token)
            self.assertEqual(str(ex.exception), "Signature has expired", msg.format("exp"))

