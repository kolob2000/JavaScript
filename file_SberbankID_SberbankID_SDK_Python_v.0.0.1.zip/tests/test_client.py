import unittest
from unittest import mock

from sberid.pkce import PKCEData, PKCEMethod
from sberid.client import Consumer, Client, Authmachine
from sberid.apiresponse import AuthorizationResponse
from tests.utils import IdTokenMock


def mocked_rndstr(*args, **kwargs):
    return "mocked_rndstr"


def mocked_requests(*args, **kwargs):
    class MockResponse:
        def __init__(self, json_data, status_code):
            self.json_data = json_data
            self.status_code = status_code
            self.content = "mocked content"

        def json(self):
            return self.json_data
    id_token = IdTokenMock()
    id_token.setUp()
    URL_DB = {
        "userinfo.do": {
            "json_data": {
                "user_info": "mocked_userinfo"
            },
            "status_code": 200
        },
        "token.do": {
            "json_data": {
                "access_token": "mocked_access_token",
                "expires_in": "mocked_expires_in",
                "token_type": "bearer",
                "scope": "openid mail",
                "id_token": id_token.id_token
            },
            "status_code": 200
        },
        "error.do": {
            "json_data": {
                "httpCode": "400",
                "httpMessage": "error_message",
                "moreInformation": "more_information"
            },
            "status_code": 400
        }
    }
    return MockResponse(**URL_DB[kwargs["url"]])


class AuthMachineClient(Client):

    def get_authorization_response(self):
        return AuthorizationResponse(
            code="mocked_code",
            state="mocked_state",
            nonce="mocked_nonce"
        )


class Test(unittest.TestCase):

    def setUp(self):
        self.consumer = Consumer(
            client_id = "mocked_aud",
            client_secret = "client_secret",
            client_crt = None,
            client_pass = None
        )
        self.authmachine = Authmachine(
            issuer = "https://online.sberbank.ru/CSAFront/index.do",
            authorization_endpoint = "auth.do",
            token_endpoint = "token.do",
            userinfo_endpoint = "userinfo.do"
        )

    @mock.patch("sberid.pkce.rndstr", side_effect=mocked_rndstr)
    @mock.patch("sberid.client.rndstr", side_effect=mocked_rndstr)
    def test_get_auth_url(self, *args):
        client = AuthMachineClient(self.consumer, self.authmachine)
        pkce = PKCEData(PKCEMethod.PLAIN, 8)
        url = client.get_authorization_url(["openid", "mail"], "redirect_url", pkce)
        expected_url = "auth.do?client_id=mocked_aud&response_type=code&scope=openid+mail&nonce=mocked_rndstr&redirect_uri=redirect_url&state=mocked_rndstr&code_challenge_method=PLAIN&code_challenge=mocked_rndstr"
        self.assertEqual(url, expected_url, "Ошибка формитрования адреса")

    @mock.patch("sberid.pkce.rndstr", side_effect=mocked_rndstr)
    @mock.patch("sberid.client.rndstr", side_effect=mocked_rndstr)
    @mock.patch("sberid.apirequest.uuid.uuid4", side_effect=mocked_rndstr)
    @mock.patch("sberid.apirequest.requests_pkcs12.post", side_effect=mocked_requests)
    @mock.patch("sberid.apirequest.requests_pkcs12.get", side_effect=mocked_requests)
    def test_get_userinfo(self, *args):
        with self.assertLogs("sberid", level="DEBUG") as cm:
            client = AuthMachineClient(self.consumer, self.authmachine)
            user_info = client.get_userinfo("redirect_url")
            self.assertEqual(user_info, {"user_info": "mocked_userinfo"}, "Ошибка формирования ответа userinfo")
        self.assertEqual(len(cm.output), 5)


