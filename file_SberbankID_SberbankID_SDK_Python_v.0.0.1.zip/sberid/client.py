import logging
from typing import List
from urllib.parse import urlencode
from abc import ABC, abstractmethod
from .apirequest import TokenRequest, UserIdRequest
from .apiresponse import AccessTokenResponse, AuthorizationResponse, SberAPIException
from .pkce import PKCEData, rndstr


class Authmachine(object):
    """Датакласс API сервера."""
    __slots__ = ("issuer", "authorization_endpoint", "token_endpoint", "userinfo_endpoint")
    
    def __init__(self, issuer : str, authorization_endpoint : str, token_endpoint : str, userinfo_endpoint : str):
        """

        :param issuer:
        :param authorization_endpoint: URL точки аутентификации
        :param token_endpoint: URL точки получения ID токена
        :param userinfo_endpoint: URL точки получения пользовательских данных
        """
        self.issuer = issuer
        self.authorization_endpoint = authorization_endpoint
        self.token_endpoint = token_endpoint
        self.userinfo_endpoint = userinfo_endpoint


class Consumer(object):
    """Датакласс потребителя."""
    __slots__ = ("client_id", "client_secret", "client_crt", "client_pass")

    def __init__(self, client_id : str, client_secret : str, client_crt : str = None, client_pass : str = None):
        """

        :param client_id: Уникальный идентификатор потребителя
        :param client_secret: Пароль доступа к API
        :param client_crt: Путь к TLS сертификату (может быть None)
        :param client_pass: Пароль к TLS тертификату (может быть None)
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.client_crt = client_crt
        self.client_pass = client_pass


class Client(ABC):
    """Клиент для доступа к API."""
    def __init__(self, consumer : Consumer, authmachine : Authmachine, logger = None):
        """

        :param consumer: Датакласс потребителя
        :param authmachine: Датакласс API сервиса
        :param logger: Объект логгирования
        """
        self.consumer = consumer
        self.authmachine = authmachine
        self.logger = logger or logging.getLogger(__name__)

    def get_authorization_url(self, scope : List[str], redirect_uri : str, pkce : PKCEData = None) -> str:
        """Формирование URL адреса аутентификации пользователя
        :param scope: Запрашиваемые наборы данных
        :param redirect_uri: URL возврата к потребителю
        :param pkce: PKCE верификатор (может быть None)
        :return: URL адреса аутентификации пользователя
        """
        args = {
            "client_id": self.consumer.client_id,
            "response_type": "code",
            "scope": " ".join(scope),
            "nonce": rndstr(),
            "redirect_uri": redirect_uri,
            "state": rndstr()
        }
        if pkce:
            args["code_challenge_method"] = pkce.code_challenge_method.name
            args["code_challenge"] = pkce.code_challenge

        url = "{0.authorization_endpoint}?{1}".format(self.authmachine, urlencode(args, True))
        self.logger.debug("Authorisation URL: {0}".format(url))
        return url

    def get_access_token(self, auth_code : str, redirect_url : str, code_verifier : str = None) -> AccessTokenResponse:
        """Получение AccessToken: выполнение запроса token.do и упаковка ответа в экземпляр AccessTokenResponse
        :param auth_code: Полученный пользователем AuthCode
        :param redirect_url: URL возврата к потребителю
        :param code_verifier: PKCE верификатор (может быть None)
        :return: AccessToken
        """
        request = TokenRequest(self.authmachine.token_endpoint, self.consumer, logger = self.logger)
        response = request.send(auth_code, redirect_url, code_verifier)
        try:
            return AccessTokenResponse(
                iss=self.authmachine.issuer,
                aud=self.consumer.client_id,
                access_token=response["access_token"],
                expires_in=response["expires_in"],
                token_type=response["token_type"],
                scope=response["scope"],
                id_token=response["id_token"]
                )
        except KeyError as ex:
            raise SberAPIException("Не корректный ответ сервера.") from ex

    @abstractmethod
    def get_authorization_response(self) -> AuthorizationResponse:
        """Преобразование запроса с полученным пользователем AuthCode в экземпляр AuthorizationResponse
        :return: AuthorizationResponse
        """
        pass

    def get_userinfo(self, redirect_url : str, code_verifier : str = None) -> dict:
        """Получение данных пользователя
        :param redirect_url: URL возврата к потребителю
        :param code_verifier: PKCE верификатор (может быть None)
        :return:
        """
        auth_code = self.get_authorization_response()
        token = self.get_access_token(auth_code.code, redirect_url, code_verifier)
        self.logger.debug(token.id_token)
        request = UserIdRequest(self.authmachine.userinfo_endpoint, self.consumer, logger = self.logger)
        response = request.send(token.access_token)
        return response

