import jwt
from jwt import InvalidTokenError


class SberAPIException(Exception): pass


class APIErrorResponse(SberAPIException):
    """
    Исключение бросается при неуспешном вызове конечных точек **token** и **userinfo**
    """
    def __init__(self, httpCode, httpMessage, moreInformation):
        """
        :param httpCode: http-статус ответа
        :param httpMessage: текст ответа
        :param moreInformation: детализация возникшей ошибки
        """
        SberAPIException.__init__(self, moreInformation)
        self.httpCode = httpCode
        self.httpMessage = httpMessage
        self.moreInformation = moreInformation


class AuthException(SberAPIException):
    """
    Исключение бросается при получении обратного редиректа с непустым параметром **error**
    """
    def __init__(self, error, state=None, nonce=None):
        """
        :param error: текст ошибки
        :param state: state запроса
        :param nonce: nonce запроса
        """
        SberAPIException.__init__(self, error)
        self.state = state
        self.nonce = nonce


class AuthorizationResponse(object):
    """
    Датакласс параметров редиректа
    """
    __slots__ = ('code', 'error', 'state', 'nonce')

    def __init__(self, code=None, error=None, state=None, nonce=None):
        """
        :param code: значение auth_code
        :param error: текст ошибки (в случае ошибки обработки запроса аутентификации)
        :param state: state запроса
        :param nonce: nonce запроса
        """
        self.code = code
        self.error = error
        self.state = state
        self.nonce = nonce
        if error:
            raise AuthException(error, state, nonce)


class AccessTokenResponse(object):
    """
    Датакласс ответа конечной точки token
    """
    __slots__ = ('access_token', 'expires_in', 'token_type', 'scope', 'id_token')

    def __init__(self, iss, aud, access_token, expires_in, token_type, scope, id_token):
        """
        :param iss: издатель токена
        :param aud: идентификатор потребителя
        :param access_token: значение access_token
        :param expires_in: дата истечения
        :param token_type: тип токена
        :param scope: набор данных
        :param id_token: значение id_token
        """
        self.access_token = access_token
        self.expires_in = expires_in
        self.token_type = token_type
        self.scope = scope
        try:
            self.id_token = jwt.decode(id_token, issuer=iss, audience=aud, algorithms=['none'], options={'verify_signature': False})
        except InvalidTokenError as ex:
            raise SberAPIException(ex) from ex
