import uuid
import logging
import requests_pkcs12
from urllib.parse import urlencode
from .apiresponse import APIErrorResponse
from abc import ABC, abstractmethod


class BaseRequest(ABC):
    def __init__(self, endpoint, consumer, logger = None):
        self.endpoint = endpoint
        self.consumer = consumer
        self.logger = logger or logging.getLogger(__name__)

    def _checkStatusCode(self, response):
        if response.status_code != 200:
            err = response.json()
            raise APIErrorResponse(httpCode = err.get("httpCode"),
                                   httpMessage = err.get("httpMessage"),
                                   moreInformation = err.get("moreInformation")
                                   )

    @abstractmethod
    def _execute(self, args, headers):
        """
        Выполнить HTTP запрос
        :param args: параметры запроса
        :param headers: заголовки запроса
        :return: ответ сервера
        """
        pass


class POSTRequest(BaseRequest):

    def _execute(self, args, headers):
        self.logger.debug(f"POST request: {self.endpoint} {args} {headers}")
        response = requests_pkcs12.post(url=self.endpoint,
                                 data=urlencode(args, True),
                                 verify=True,
                                 pkcs12_filename=self.consumer.client_crt,
                                 pkcs12_password=self.consumer.client_pass,
                                 headers=headers
                                 )
        self.logger.debug("POST result: ({0.status_code}) {0.content}".format(response))
        self._checkStatusCode(response)
        return response


class GETRequest(BaseRequest):

    def _execute(self, args, headers):
        self.logger.debug(f"GET request: {self.endpoint} {args} {headers}")
        response = requests_pkcs12.get(url=self.endpoint,
                                 params=urlencode(args, True),
                                 verify=True,
                                 pkcs12_filename=self.consumer.client_crt,
                                 pkcs12_password=self.consumer.client_pass,
                                 headers=headers
                                 )
        self.logger.debug("GET result: ({0.status_code}) {0.content}".format(response))
        self._checkStatusCode(response)
        return response


class TokenRequest(POSTRequest):
    """Запрос на получение AccessToken и IdToken"""
    def send(self, authCode : str, redirect_url : str, code_verifier : str = None):
        """
        Отправка запроса
        :param authCode: значение auth_code
        :param redirect_url: адрес редиректа на потребителя
        :param code_verifier: проверочное значение PKCE (может быть None)
        :return: http ответ
        """
        args = {
            "grant_type": "authorization_code",
            "code": authCode,
            "client_id": self.consumer.client_id,
            "client_secret": self.consumer.client_secret,
            "redirect_uri": redirect_url
        }
        if code_verifier:
            args["code_verifier"] = code_verifier
        headers = {
            "accept": "application/json",
            "rquid": str(uuid.uuid4()).replace("-", ""),
            "x-ibm-client-id": self.consumer.client_id,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        return self._execute(args, headers).json()


class UserIdRequest(GETRequest):
    """Запрос на получение пользовательских данных"""
    def send(self, access_token :str) -> dict:
        """
        Отправка запроса
        :param access_token: значение access_token
        :return: http ответ
        """
        headers = {
            "x-introspect-rquid": str(uuid.uuid4()).replace("-", ""),
            "x-ibm-client-id": self.consumer.client_id,
            "authorization": f"Bearer {access_token}",
            "accept": "application/json"
        }
        return self._execute(args={}, headers=headers).json()

