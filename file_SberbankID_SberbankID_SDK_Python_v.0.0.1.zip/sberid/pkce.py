import base64
import string
import hashlib
from enum import Enum
from secrets import choice


def rndstr(size : int = 16) -> str:
    """
    Возвращает строку случайных ascii букв и цифр.

    :param size: Длина строки
    :return: Строка
    """
    _basech = string.ascii_letters + string.digits
    return "".join([choice(_basech) for _ in range(size)])


class S256(object):
    def encode(self, data : str) -> str:
        __hash = hashlib.sha256()
        __hash.update(data.encode("UTF-8"))
        return base64.urlsafe_b64encode(__hash.digest()).rstrip(b"=").decode("UTF-8")


class PlainHash(object):
    def encode(self, data : str) -> str:
        return data


class PKCEMethod(Enum):
    """Набор методов кодирования значения PKCE code_verifier."""
    S256 = S256
    PLAIN = PlainHash

    def encode(self, verifier : str) -> str:
        """
        Кодирует верификатор
        :param verifier: верификатор
        :return: закодированное значение
        """
        return self.value().encode(verifier)


class PKCEData(object):
    """
    Данные для реализации алгоритма PKCE
    """
    __slots__ = ("code_challenge_method", "code_verifier")

    def __init__(self, code_challenge_method : PKCEMethod, len : int = 64):
        """
        :param code_challenge_method: метод хеширования значения code_challenge
        :param len: длина значения code_challenge
        """
        self.code_challenge_method = code_challenge_method
        self.code_verifier = rndstr(len)

    @property
    def code_challenge(self):
        return self.code_challenge_method.encode(self.code_verifier)
