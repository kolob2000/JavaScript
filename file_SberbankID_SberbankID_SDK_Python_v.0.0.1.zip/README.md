PySberId
========

Python библиотека для серверных приложений, упрощающая получение Access Token и UserInfo.


Установка
---------
Python документация по установке пакетов расположена на сайте [packaging.python.org](https://packaging.python.org/tutorials/installing-packages/)

#### Установка через **pip**:
```sh
    $ python setup.py sdist
    $ pip install dist\pySberId-0.0.1.tar.gz
```

#### Установка из исходников через **setuptools**
```sh
    $ python setup.py install
```

Использование
-------------

#### Необходимый мпорт

```python
from sberid.client import Client, Consumer, Authmachine
from sberid.pkce import  PKCEData, PKCEMethod
from sberid.apiresponse import AuthorizationResponse
```

#### Создание API-клиента

##### Датаклассы Consumer и Authmachine

Класс **Consumer** описывает параметры потребителя сервиса:

    client_id: Уникальный идентификатор потребителя
    client_secret: Пароль доступа к API
    client_crt: Путь к TLS сертификату (может быть None)
    client_pass: Пароль к TLS сертификату (может быть None)

Класс **Authmachine** описывает параметры сервиса аутентификации:

    issuer: URL-адрес, который сервис аутентификации утверждает в качестве своего идентификатора.
    authorization_endpoint: URL точки аутентификации
    token_endpoint: URL точки получения ID токена
    userinfo_endpoint: URL точки получения пользовательских данных

##### PKCEData и PKCEMethod

Вспомогательные классы для повышения защищенности передачи данных пользователя с использованием алгоритма [PKCE](https://tools.ietf.org/html/rfc7636).

##### Client и AuthorizationResponse

Абстрактный класс **Client** реализует основные методы для взаимодействия с сервисом аутентификации и получения пользовательских данных:
```python
    def get_authorization_url(self, scope : List[str], redirect_uri : str, pkce : PKCEData = None) -> str:
        """Формирование URL адреса аутентификации пользователя
        :param scope: Запрашиваемые наборы данных
        :param redirect_uri: URL возврата к потребителю
        :param pkce: PKCE верификатор (может быть None)
        :return: URL адреса аутентификации пользователя
        """
``` 

```python
    def get_userinfo(self, redirect_url : str, code_verifier : str = None) -> dict:
        """Получение данных пользователя
        :param redirect_url: URL возврата к потребителю
        :param code_verifier: PKCE верификатор (может быть None)
        :return:
        """
```

Необходима реализация метода:
```python
    def get_authorization_response(self) -> AuthorizationResponse:
        """Преобразование запроса с полученным пользователем AuthCode в экземпляр AuthorizationResponse
        :return: AuthorizationResponse
        """
```

##### Ошибки
Все исключения, генерируемые библиотекой являются наследниками класса **SberAPIException**

###### AuthException
Исключение бросается при получении обратного редиректа с непустым параметром **error** 

###### APIErrorResponse
Исключение бросается при неуспешном вызове конечных точек **token** и **userinfo**

#### Пример
Полный пример с использованием фреймворка Flask содержится в исходном коде библиотеки.

##### Пример создания датаклассов:
```python
AUTHMACHINE = Authmachine(
    issuer = "https://online.sberbank.ru/CSAFront/index.do",
    authorization_endpoint = "https://csa-psi.testonline.sberbank.ru:9445/CSAFront/oidc/authorize.do",
    token_endpoint = "https://api.sberbank.ru/ru/prod/tokens/v2/oidc", # url на получение access token (для подключений через двусторонний TLS)
                    # https://sec.api.sberbank.ru/ru/prod/tokens/v2/oidc - для подключений через ФПСУ
                    # https://open.api.sberbank.ru/ru/prod/tokens/v2/oidc - для подключений через односторонний TLS
    userinfo_endpoint = "https://api.sberbank.ru/ru/prod/sberbankid/v2.1/userInfo" # url на получение пользовательских данных (для подключений через двусторонний TLS)
                    # https://sec.api.sberbank.ru/ru/prod/sberbankid/v2.1/userinfo - для подключений через ФПСУ
                    # https://open.api.sberbank.ru/ru/prod/sberbankid/v2.1/userinfo - для подключений через односторонний TLS
)
CONSUMER = Consumer(
    client_id = "6a0e103b-1873-4ed5-9903-b4fb51192b23",
    client_secret = "oYBjtOQmQNX4cMAmnKxAnvoGrWeccGKzKxvCKqtm0jQ",
    client_crt = r"cert.p12",
    client_pass = "put_your_password_here"
)
```

##### Реализация класса **Client** (пример для Flask):
```python
class AuthMachineClient(Client):

    def get_authorization_response(self):
        return AuthorizationResponse(
            code=request.args.get("code"),
            error=request.args.get("error"),
            state=request.args.get("state"),
            nonce=request.args.get("nonce")
            )

```

##### Получение адреса аутентификации пользователя:
```python
    client = AuthMachineClient(CONSUMER, AUTHMACHINE)
    pkce = PKCEData(PKCEMethod.S256, 64)
    # необходимо сохранить code_verifier для последующей проверки
    session["pkce"] = pkce.code_verifier
    url = client.get_authorization_url(CONSUMER_SCOPE, redirect_url, pkce)
```

##### Получение данных пользователя после его успешной аутентификации:
```python
    client = AuthMachineClient(CONSUMER, AUTHMACHINE)
    user_info = client.get_userinfo(redirect_url, session.get("pkce"))
```

##### Логгирование
Класс **Client** принимает не обязательный параметр **logger** в конструкторе. В случае его отсутствия используется стандартный логгер.

