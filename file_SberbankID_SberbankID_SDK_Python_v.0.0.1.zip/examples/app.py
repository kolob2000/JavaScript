import os
import json

from sberid.client import Client, Consumer, Authmachine
from sberid.pkce import  PKCEData, PKCEMethod
from sberid.apiresponse import AuthorizationResponse, SberAPIException

from flask import Flask, request, render_template, redirect, session, url_for
from logging.config import dictConfig

with open(os.path.join(os.path.dirname(__file__), "config.json"), "rt") as f:
    conf = json.load(f)

dictConfig(conf["logging"])
CONSUMER_SCOPE = ["openid", "email"]
AUTHMACHINE = Authmachine(
    issuer = conf["authmachine"]["issuer"],
    authorization_endpoint = conf["authmachine"]["authorization_endpoint"],
    token_endpoint = conf["authmachine"]["token_endpoint"],
    userinfo_endpoint = conf["authmachine"]["userinfo_endpoint"]
)
CONSUMER = Consumer(
    client_id = conf["consumer"]["client_id"],
    client_secret = conf["consumer"]["client_secret"],
    client_crt = conf["consumer"]["client_crt"],
    client_pass = conf["consumer"]["client_pass"]
)


class AuthMachineClient(Client):

    def get_authorization_response(self):
        return AuthorizationResponse(
            code=request.args.get("code"),
            error=request.args.get("error"),
            state=request.args.get("state"),
            nonce=request.args.get("nonce")
            )


app = Flask(__name__)
app.secret_key = b"23487384738748374837"


@app.errorhandler(SberAPIException)
def handle_exception(e):
    return render_template("error.jinja", err=e)


@app.route("/")
def index():
    return render_template("index.jinja", user_info=session.get("user_info"))


@app.route("/oidc-login")
def oidc_login():
    client = AuthMachineClient(CONSUMER, AUTHMACHINE)
    if request.is_secure:
        proto = "https://"
    else:
        proto = "http://"
    redirect_url = proto + request.host + url_for("auth_callback")
    pkce = PKCEData(PKCEMethod.S256, 64)
    session["pkce"] = pkce.code_verifier
    url = client.get_authorization_url(CONSUMER_SCOPE, redirect_url, pkce)
    return redirect(url)


@app.route("/login")
def auth_callback():
    if request.is_secure:
        proto = "https://"
    else:
        proto = "http://"
    redirect_url = proto + request.host + url_for("auth_callback")
    client = AuthMachineClient(CONSUMER, AUTHMACHINE)
    user_info = client.get_userinfo(redirect_url, session.get("pkce"))
    session["user_info"] = user_info
    if "pkce" in session:
        del session["pkce"]
    return redirect(url_for("index"))


@app.route("/logout")
def logout():
    if "user_info" in session:
        del session["user_info"]
    return redirect(url_for("index"))


app.run(port=8080)
